from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request, Response

class RegionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        region = request.headers.get("X-Region-ID")
        if not region:
            return Response("X-Region-ID header required", status_code=400)
        request.state.region = region
        response = await call_next(request)
        return response