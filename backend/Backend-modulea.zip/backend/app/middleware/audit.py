from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request
from sqlalchemy.orm import Session
from ..database.session import SessionLocal
from ..database.models import AuditLog
from datetime import datetime

class AuditLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        db: Session = SessionLocal()
        try:
            user_id = None
            if request.state and hasattr(request.state, "user"):
                user_id = getattr(request.state, "user").id
            log = AuditLog(
                user_id=user_id,
                action="API_CALL",
                path=request.url.path,
                method=request.method,
                ip=request.client.host,
                timestamp=datetime.utcnow(),
                details=str(await request.body())
            )
            db.add(log)
            db.commit()
        except Exception:
            db.rollback()
        finally:
            db.close()
        return response