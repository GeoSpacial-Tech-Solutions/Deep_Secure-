from fastapi import APIRouter, WebSocket

router = APIRouter()

@router.websocket("/ws/detect")
async def websocket_detect(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_json({"status": "ready"})
    # Demo: echo
    while True:
        data = await websocket.receive_text()
        await websocket.send_text(f"Echo: {data}")