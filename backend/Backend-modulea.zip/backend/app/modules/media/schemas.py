from pydantic import BaseModel
from typing import Optional, Dict
from datetime import datetime

class MediaUpload(BaseModel):
    region: str
    type: str

class MediaOut(BaseModel):
    id: int
    filename: str
    uuid: str
    user_id: int
    region: str
    type: str
    metadata: Optional[Dict]
    upload_time: datetime

    class Config:
        orm_mode = True