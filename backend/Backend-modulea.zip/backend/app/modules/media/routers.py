import os
import uuid as uuid_lib
from fastapi import APIRouter, File, UploadFile, Form, Depends, Request, HTTPException
from sqlalchemy.orm import Session
from ...core.auth import get_current_user
from ...database.session import get_db
from .schemas import MediaOut
from .crud import create_media

from ...config import settings

router = APIRouter()

@router.post("/upload", response_model=MediaOut)
async def upload_media(
    request: Request,
    file: UploadFile = File(...),
    region: str = Form(...),
    type: str = Form(...),
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not file.filename.endswith(".mp4"):
        raise HTTPException(status_code=400, detail="Only .mp4 files supported")
    uuid_str = str(uuid_lib.uuid4())
    upload_dir = settings.UPLOAD_DIR
    os.makedirs(upload_dir, exist_ok=True)
    filename = f"{uuid_str}.mp4"
    file_path = os.path.join(upload_dir, filename)
    with open(file_path, "wb") as f:
        contents = await file.read()
        f.write(contents)
    media = create_media(db, filename, uuid_str, current_user.id, region, type, metadata={"original_filename": file.filename})
    return media