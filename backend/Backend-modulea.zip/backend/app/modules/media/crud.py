from sqlalchemy.orm import Session
from ...database.models import Media
from typing import Optional

def create_media(db: Session, filename: str, uuid: str, user_id: int, region: str, type: str, metadata: dict = None):
    media = Media(
        filename=filename,
        uuid=uuid,
        user_id=user_id,
        region=region,
        type=type,
        metadata=metadata or {},
    )
    db.add(media)
    db.commit()
    db.refresh(media)
    return media

def get_media_by_uuid(db: Session, uuid: str) -> Optional[Media]:
    return db.query(Media).filter(Media.uuid == uuid).first()