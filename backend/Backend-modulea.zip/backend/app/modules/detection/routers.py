import os
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from ...database.session import get_db
from ...core.auth import get_current_user
from ..media.crud import get_media_by_uuid
from .ai import simulate_detection
from .crud import create_detection, get_recent_detections_by_region
from .schemas import DetectionResult

from datetime import datetime

router = APIRouter()

@router.post("/run/{uuid}", response_model=DetectionResult)
def run_detection(uuid: str, request: Request, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    media = get_media_by_uuid(db, uuid)
    if not media:
        raise HTTPException(status_code=404, detail="Media not found")
    file_path = os.path.join(media.filename)
    classification, confidence, details = simulate_detection(file_path)
    detection = create_detection(db, media.id, classification, confidence, media.region, details)
    return DetectionResult(
        timestamp=detection.detected_at,
        filename=media.filename,
        classification=classification,
        confidence=confidence,
        region=media.region,
        details=details
    )

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    logs = get_recent_detections_by_region(db)
    result = {}
    for region, detections in logs.items():
        result[region] = [
            {
                "timestamp": det.detected_at,
                "filename": det.media.filename if det.media else "",
                "classification": det.result,
                "confidence": det.confidence,
                "region": det.region,
                "details": det.details
            }
            for det in detections
        ]
    return result