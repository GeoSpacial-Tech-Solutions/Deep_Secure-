import random

def simulate_detection(file_path: str):
    # Simulate a detection
    confidence = round(random.uniform(0.65, 0.99), 2)
    classification = "deepfake" if confidence > 0.85 else "real"
    details = {
        "model_version": "v1.0",
        "simulated": True
    }
    return classification, confidence, details