from pydantic import BaseModel
from typing import Dict, Any
from datetime import datetime

class DetectionResult(BaseModel):
    timestamp: datetime
    filename: str
    classification: str
    confidence: float
    region: str
    details: Dict[str, Any] = {}

class DetectionLogGroup(BaseModel):
    region: str
    logs: list[DetectionResult]