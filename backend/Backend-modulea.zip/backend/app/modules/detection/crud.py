from sqlalchemy.orm import Session
from ...database.models import Detection, Media
from datetime import datetime

def create_detection(db: Session, media_id: int, result: str, confidence: float, region: str, details: dict):
    detection = Detection(
        media_id=media_id,
        result=result,
        confidence=confidence,
        detected_at=datetime.utcnow(),
        region=region,
        details=details,
    )
    db.add(detection)
    db.commit()
    db.refresh(detection)
    return detection

def get_recent_detections_by_region(db: Session, limit=20):
    from sqlalchemy import desc
    detections = (
        db.query(Detection)
        .order_by(desc(Detection.detected_at))
        .limit(limit)
        .all()
    )
    by_region = {}
    for det in detections:
        by_region.setdefault(det.region, []).append(det)
    return by_region