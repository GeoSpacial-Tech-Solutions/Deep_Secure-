import httpx
from fastapi import APIRouter

router = APIRouter()

@router.get("/random", tags=["jokes"])
async def get_random_joke():
    """
    Fetch a random joke from an external API (Official Joke API).
    """
    async with httpx.AsyncClient() as client:
        res = await client.get("https://official-joke-api.appspot.com/jokes/random")
        if res.status_code == 200:
            data = res.json()
            return {
                "setup": data.get("setup"),
                "punchline": data.get("punchline"),
                "type": data.get("type")
            }
        else:
            return {"error": "Could not fetch a joke at this time."}