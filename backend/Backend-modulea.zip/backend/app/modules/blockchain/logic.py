def hash_media_to_blockchain(media_hash: str, gps: dict):
    # Simulate blockchain transaction
    return {"tx_id": "dummy_tx_id", "network": "testnet"}