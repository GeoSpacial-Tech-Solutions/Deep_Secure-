from fastapi import APIRouter, Depends, HTTPException
from .schemas import (
    BiometricEnrollRequest, BiometricScanRequest, BiometricScanResult,
    QRVerifyRequest, QRVerifyResult
)
from .logic import enroll_eye_movement, match_eye_movement, verify_qr_identity
from datetime import datetime

router = APIRouter()

@router.post("/enroll-eye", response_model=dict)
def enroll_eye(req: BiometricEnrollRequest):
    success = enroll_eye_movement(req.user_id, req.eye_movement_template)
    return {"enrolled": success}

@router.post("/scan-eye", response_model=BiometricScanResult)
def scan_eye(req: BiometricScanRequest):
    matched, confidence, timestamp = match_eye_movement(req.user_id, req.eye_movement_scan)
    return BiometricScanResult(
        matched=matched,
        confidence=confidence,
        timestamp=timestamp
    )

@router.post("/verify-qr", response_model=QRVerifyResult)
def verify_qr(req: QRVerifyRequest):
    valid, user_id, timestamp = verify_qr_identity(req.qr_data)
    return QRVerifyResult(
        valid=valid,
        user_id=user_id,
        timestamp=timestamp
    )