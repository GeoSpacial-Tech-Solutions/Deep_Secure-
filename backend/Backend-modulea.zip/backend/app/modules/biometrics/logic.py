from datetime import datetime
import random

# Simulate a biometric DB in memory for demo (replace with real DB in prod)
BIOMETRIC_STORE = {}

def enroll_eye_movement(user_id: int, template: str):
    BIOMETRIC_STORE[user_id] = template
    return True

def match_eye_movement(user_id: int, scan: str):
    # Simulate a fuzzy match (in real life use ML/CV model)
    stored = BIOMETRIC_STORE.get(user_id)
    confidence = round(random.uniform(0.7, 0.99), 2) if stored else 0.0
    matched = stored is not None and confidence > 0.8
    return matched, confidence, datetime.utcnow()

def verify_qr_identity(qr_data: str):
    # Simulate QR containing user_id as plain text. In production, use JWT or signed QR.
    try:
        user_id = int(qr_data)
        valid = user_id in BIOMETRIC_STORE
        return valid, user_id if valid else None, datetime.utcnow()
    except Exception:
        return False, None, datetime.utcnow()