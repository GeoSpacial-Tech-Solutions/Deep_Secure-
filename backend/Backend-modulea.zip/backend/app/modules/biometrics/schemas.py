from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class BiometricEnrollRequest(BaseModel):
    user_id: int
    eye_movement_template: str  # base64 or encrypted vector

class BiometricScanRequest(BaseModel):
    user_id: int
    eye_movement_scan: str  # live scan data, base64 or vector

class BiometricScanResult(BaseModel):
    matched: bool
    confidence: float
    timestamp: datetime
    method: str = "eye-movement"

class QRVerifyRequest(BaseModel):
    qr_data: str  # scanned QR contents

class QRVerifyResult(BaseModel):
    valid: bool
    user_id: Optional[int]
    timestamp: datetime