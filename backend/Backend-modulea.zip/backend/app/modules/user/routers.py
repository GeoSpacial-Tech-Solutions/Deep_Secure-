from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ...database.session import get_db
from ...modules.user.schemas import UserCreate, UserOut, Token
from ...modules.user.crud import get_user_by_email, create_user, authenticate_user
from ...core.security import create_access_token
from ...core.auth import get_current_user, get_current_admin

router = APIRouter()

@router.post("/register", response_model=UserOut)
def register(user: UserCreate, db: Session = Depends(get_db)):
    db_user = get_user_by_email(db, user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return create_user(db, user.email, user.password, user.full_name)

@router.post("/login", response_model=Token)
def login(form_data: UserCreate, db: Session = Depends(get_db)):
    user = authenticate_user(db, form_data.email, form_data.password)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid credentials")
    access_token = create_access_token(data={"sub": user.id})
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=UserOut)
def read_users_me(current_user=Depends(get_current_user)):
    return current_user

@router.get("/admin/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), current_admin=Depends(get_current_admin)):
    return db.query(User).all()