from sqlalchemy.orm import Session
from ...database.models import User
from ...core.security import get_password_hash, verify_password

def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()

def create_user(db: Session, email: str, password: str, full_name: str = "", is_admin=False):
    db_user = User(
        email=email, 
        hashed_password=get_password_hash(password),
        full_name=full_name,
        is_admin=is_admin,
        role="admin" if is_admin else "user"
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def authenticate_user(db: Session, email: str, password: str):
    user = get_user_by_email(db, email)
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user