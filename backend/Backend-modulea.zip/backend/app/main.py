import os
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.staticfiles import StaticFiles

from .config import settings
from .database.base import Base
from .database.session import engine
from .middleware.audit import AuditLogMiddleware
from .middleware.region import RegionMiddleware
from .modules.user.routers import router as user_router
from .modules.media.routers import router as media_router
from .modules.detection.routers import router as detection_router
from .modules.realtime.routers import router as realtime_router
from .modules.blockchain.routers import router as blockchain_router
from .modules.child_protection.routers import router as child_router

# Create all tables (ensure Alembic used for prod)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Deepfake Detection System",
    description="Modular Deepfake Detection and Geospatial Integrity API",
    version="1.0.0"
)

# CORS - allow frontend and mobile origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Region Middleware
app.add_middleware(RegionMiddleware)

# Audit Logging Middleware
app.add_middleware(AuditLogMiddleware)

# Routers
app.include_router(user_router, prefix="/users", tags=["users"])
app.include_router(media_router, prefix="/media", tags=["media"])
app.include_router(detection_router, prefix="/detection", tags=["detection"])
app.include_router(realtime_router, prefix="/realtime", tags=["realtime"])
app.include_router(blockchain_router, prefix="/blockchain", tags=["blockchain"])
app.include_router(child_router, prefix="/child-protection", tags=["child-protection"])

# Serve uploaded media files statically (for demo)
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

@app.get("/", tags=["root"])
async def root():
    return {"message": "Deepfake Detection System API"}

# Custom Exception Handler for 422
@app.exception_handler(422)
async def validation_exception_handler(request: Request, exc):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()},
    )