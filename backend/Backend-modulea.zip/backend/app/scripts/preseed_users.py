import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from database.session import SessionLocal
from modules.user.crud import create_user, get_user_by_email

db = SessionLocal()
try:
    # Create admin
    if not get_user_by_email(db, "admin@local"):
        create_user(db, "admin@local", "adminpass", "Admin", is_admin=True)
    # Create test user
    if not get_user_by_email(db, "user@local"):
        create_user(db, "user@local", "userpass", "User", is_admin=False)
    print("Users created.")
finally:
    db.close()