import os
from dotenv import load_dotenv
from pydantic import BaseSettings

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

class Settings(BaseSettings):
    APP_NAME: str = "DeepfakeDetection"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "supersecret")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    BACKEND_CORS_ORIGINS: str = os.getenv("CORS_ORIGINS", "http://localhost,http://localhost:3000")
    CORS_ORIGINS: list = [origin.strip() for origin in BACKEND_CORS_ORIGINS.split(",")]
    SQLALCHEMY_DATABASE_URL: str = os.getenv(
        "DATABASE_URL", "sqlite:///./test.db"
    )
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
    UPLOAD_DIR: str = os.getenv("UPLOAD_DIR", os.path.join(os.path.dirname(__file__), "..", "uploads"))
    MODEL_DIR: str = os.getenv("MODEL_DIR", os.path.join(os.path.dirname(__file__), "..", "models"))
    RATE_LIMIT: int = int(os.getenv("RATE_LIMIT", 60))

settings = Settings()