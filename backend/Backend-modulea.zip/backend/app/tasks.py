from celery import Celery
from .config import settings

celery = Celery(
    "tasks",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
)

@celery.task
def run_deepfake_detection_task(media_path):
    # Simulate async detection
    import time, random
    time.sleep(2)
    return {"classification": random.choice(["real", "deepfake"]), "confidence": random.uniform(0.7, 0.99)}