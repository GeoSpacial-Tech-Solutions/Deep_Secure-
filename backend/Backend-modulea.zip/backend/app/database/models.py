from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Boolean, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from .base import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    role = Column(String, default="user")  # user, admin
    created_at = Column(DateTime, default=datetime.utcnow)

class Media(Base):
    __tablename__ = "media"
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String, index=True)
    uuid = Column(String, unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    region = Column(String)
    type = Column(String)  # video, audio, image, etc
    metadata = Column(JSON)
    upload_time = Column(DateTime, default=datetime.utcnow)
    user = relationship("User")

class Detection(Base):
    __tablename__ = "detections"
    id = Column(Integer, primary_key=True, index=True)
    media_id = Column(Integer, ForeignKey("media.id"))
    result = Column(String)
    confidence = Column(Float)
    detected_at = Column(DateTime, default=datetime.utcnow)
    region = Column(String)
    details = Column(JSON)
    media = relationship("Media")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String)
    path = Column(String)
    method = Column(String)
    ip = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)
    details = Column(Text)
    user = relationship("User")